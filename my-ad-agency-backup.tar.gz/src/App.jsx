import './index.css'
import { createClient } from '@supabase/supabase-js'
import { useEffect, useState } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import AuthForm from './AuthForm'
import CreateListing from './CreateListing'
import PublisherDashboard from './PublisherDashboard'
import AdvertiserDashboard from './AdvertiserDashboard'
import CreateCampaign from './CreateCampaign'
import CampaignDashboard from './CampaignDashboard'
import DashboardLayout from './DashboardLayout' // Make sure this file exists in your src folder

// Initialize Supabase client with your anon key from the Supabase dashboard
const supabase = createClient(
  'https://pczzwgluhgrjuxjadyaq.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBjenp3Z2x1aGdyanV4amFkeWFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDAxNjY0MTQsImV4cCI6MjA1NTc0MjQxNH0.dpVupxUEf8be6aMG8jJZFduezZjaveCnUhI9p7G7ud0'
)

function Home({ session, handleLogout }) {
  const [role, setRole] = useState('')

  useEffect(() => {
    const fetchUserRole = async () => {
      if (session && session.user && session.user.id) {
        const { data, error } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', session.user.id)
          .single()
        if (error) {
          console.error('Error fetching user role:', error)
        } else if (data) {
          setRole(data.role)
        }
      }
    }
    fetchUserRole()
  }, [session])

  return (
    <div className="p-4 bg-blue-500 text-white min-h-screen">
      <h1 className="text-2xl mb-4">Welcome to AdSync</h1>
      <p>
        Welcome, {session.user.email} (Role: {role || 'unknown'})
      </p>
      <nav className="my-4">
        {role === 'publisher' && (
          <>
            <a href="/publisher-dashboard" className="text-blue-300 underline mr-4">
              Publisher Dashboard
            </a>
            <a href="/create-listing" className="text-blue-300 underline mr-4">
              Create Listing
            </a>
          </>
        )}
        {role === 'advertiser' && (
          <>
            <a href="/advertiser-dashboard" className="text-blue-300 underline mr-4">
              Advertiser Dashboard
            </a>
            <a href="/create-campaign" className="text-blue-300 underline mr-4">
              Create Campaign
            </a>
            <a href="/campaigns" className="text-blue-300 underline">
              Campaign Dashboard
            </a>
          </>
        )}
      </nav>
      <button 
        onClick={handleLogout} 
        className="bg-red-500 p-2 rounded mt-4"
      >
        Logout
      </button>
    </div>
  )
}

function App() {
  const [session, setSession] = useState(null)
  const [error, setError] = useState(null)

  // Check session on mount
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
    })

    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session)
    })

    return () => authListener.subscription.unsubscribe()
  }, [])

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut()
    if (error) setError(error.message)
    else {
      setSession(null)
    }
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            session ? (
              <DashboardLayout user={session.user} onLogout={handleLogout}>
                <Home session={session} handleLogout={handleLogout} />
              </DashboardLayout>
            ) : (
              <AuthForm setSession={setSession} />
            )
          }
        />
        <Route
          path="/create-listing"
          element={
            session ? (
              <DashboardLayout user={session.user} onLogout={handleLogout}>
                <CreateListing session={session} />
              </DashboardLayout>
            ) : (
              <AuthForm setSession={setSession} />
            )
          }
        />
        <Route
          path="/publisher-dashboard"
          element={
            session ? (
              <DashboardLayout user={session.user} onLogout={handleLogout}>
                <PublisherDashboard session={session} />
              </DashboardLayout>
            ) : (
              <AuthForm setSession={setSession} />
            )
          }
        />
        <Route
          path="/advertiser-dashboard"
          element={
            session ? (
              <DashboardLayout user={session.user} onLogout={handleLogout}>
                <AdvertiserDashboard session={session} />
              </DashboardLayout>
            ) : (
              <AuthForm setSession={setSession} />
            )
          }
        />
        <Route
          path="/create-campaign"
          element={
            session ? (
              <DashboardLayout user={session.user} onLogout={handleLogout}>
                <CreateCampaign session={session} />
              </DashboardLayout>
            ) : (
              <AuthForm setSession={setSession} />
            )
          }
        />
        <Route
          path="/campaigns"
          element={
            session ? (
              <DashboardLayout user={session.user} onLogout={handleLogout}>
                <CampaignDashboard session={session} />
              </DashboardLayout>
            ) : (
              <AuthForm setSession={setSession} />
            )
          }
        />
      </Routes>
    </BrowserRouter>
  )
}

export default App
