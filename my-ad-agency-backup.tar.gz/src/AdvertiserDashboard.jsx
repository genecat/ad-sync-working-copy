import React, { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client with your project URL and anon key
const supabase = createClient(
  'https://pczzwgluhgrjuxjadyaq.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBjenp3Z2x1aGdyanV4amFkeWFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDAxNjY0MTQsImV4cCI6MjA1NTc0MjQxNH0.dpVupxUEf8be6aMG8jJZFduezZjaveCnUhI9p7G7ud0'
);

function AdvertiserDashboard({ session }) {
  const [campaigns, setCampaigns] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCampaigns = async () => {
      setError(null);
      try {
        // Use the advertiser's ID from the session
        const advertiserId = session.user.id;
        const { data, error } = await supabase
          .from('campaigns')
          .select('*')
          .eq('campaign_details.advertiser_id', advertiserId);
        if (error) throw error;
        setCampaigns(data || []);
      } catch (err) {
        setError(err.message);
      }
    };

    fetchCampaigns();
  }, [session]);

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Advertiser Dashboard</h1>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      {campaigns.length > 0 ? (
        <div className="grid grid-cols-1 gap-4">
          {campaigns.map((campaign) => (
            <div key={campaign.id} className="border p-4 rounded shadow bg-white">
              <h2 className="text-xl font-semibold mb-2">{campaign.name}</h2>
              <p>
                <strong>Budget:</strong> ${campaign.campaign_details?.budget || 'N/A'}
              </p>
              <p>
                <strong>Daily Limit:</strong> ${campaign.campaign_details?.dailyLimit || 'N/A'}
              </p>
              <p>
                <strong>Target URL:</strong>{' '}
                {campaign.campaign_details?.targetURL ? (
                  <a
                    href={campaign.campaign_details.targetURL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 underline"
                  >
                    {campaign.campaign_details.targetURL}
                  </a>
                ) : (
                  'N/A'
                )}
              </p>
              <p>
                <strong>End Date:</strong>{' '}
                {campaign.campaign_details?.endDate
                  ? `${campaign.campaign_details.endDate.year}-${campaign.campaign_details.endDate.month}-${campaign.campaign_details.endDate.day}`
                  : 'N/A'}
              </p>
              {/* Additional campaign details can be added here */}
            </div>
          ))}
        </div>
      ) : (
        <p>No campaigns found.</p>
      )}
    </div>
  );
}

export default AdvertiserDashboard;
