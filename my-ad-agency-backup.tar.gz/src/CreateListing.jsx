import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client (using your anon key)
const supabase = createClient(
  'https://pczzwgluhgrjuxjadyaq.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBjenp3Z2x1aGdyanV4amFkeWFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDAxNjY0MTQsImV4cCI6MjA1NTc0MjQxNH0.dpVupxUEf8be6aMG8jJZFduezZjaveCnUhI9p7G7ud0'
);

// Sample list of available ad frames
const availableFrames = [
  { id: 'frame1', size: '300x250' },
  { id: 'frame2', size: '728x90' },
  { id: 'frame3', size: '640x480' },
  { id: 'frame4', size: '300x90' },
];

const CreateListing = ({ session }) => {
  // State for basic listing details, including a "category" dropdown and a "website" field.
  const [listingDetails, setListingDetails] = useState({
    title: '',
    category: '',
    website: '',
  });
  // State for ad frame selection; each key stores both price and the frame's size.
  const [selectedFrames, setSelectedFrames] = useState({});
  // Generated embed code
  const [embedCode, setEmbedCode] = useState('');
  // Message for success or error
  const [saveMessage, setSaveMessage] = useState('');
  // State for fetched user role
  const [role, setRole] = useState('');

  // Fetch the user's role from the profiles table once the session is available.
  useEffect(() => {
    const fetchUserRole = async () => {
      if (session && session.user && session.user.id) {
        const { data, error } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', session.user.id)
          .single();
        if (error) {
          console.error('Error fetching user role:', error);
        } else if (data) {
          setRole(data.role);
        }
      }
    };
    fetchUserRole();
  }, [session]);

  // Handle changes for title, category, and website inputs
  const handleDetailChange = (e) => {
    const { name, value } = e.target;
    setListingDetails({ ...listingDetails, [name]: value });
  };

  // Toggle ad frame selection on/off.
  // When a frame is selected, we store both the price per click and the frame's size.
  const toggleFrame = (frameId) => {
    setSelectedFrames((prev) => {
      if (prev[frameId]) {
        // If already selected, remove it.
        const updated = { ...prev };
        delete updated[frameId];
        return updated;
      }
      // Otherwise, add it with a default price (empty string) and store its size.
      const frameInfo = availableFrames.find((f) => f.id === frameId);
      return {
        ...prev,
        [frameId]: {
          pricePerClick: '',
          size: frameInfo.size,
        },
      };
    });
  };

  // Update the price per click for a selected frame.
  const updatePrice = (frameId, newPrice) => {
    setSelectedFrames((prev) => ({
      ...prev,
      [frameId]: {
        ...prev[frameId],
        pricePerClick: newPrice,
      },
    }));
  };

  // Generate embed code for each selected ad frame as an iframe.
  const generateCode = () => {
    let code = '<!-- Ad Exchange Embed Code Start -->\n';
    Object.keys(selectedFrames).forEach((frameKey) => {
      const frameData = selectedFrames[frameKey];
      const size = frameData.size || 'Unknown Dimensions';
      const [width, height] = size.split('x');

      code += `<iframe src="http://localhost:3000/serve-ad/YOUR_LISTING_ID?frame=${frameKey}" `;
      code += `width="${width}" height="${height}" style="border:none;"></iframe>\n\n`;
    });
    code += '<!-- Ad Exchange Embed Code End -->';
    setEmbedCode(code);
  };

  // Save the listing to the database, storing all selected frames.
  const saveListing = async () => {
    // Check if user is logged in.
    if (!session) {
      setSaveMessage('You must be logged in to save a listing.');
      return;
    }
    // Check if the fetched role is "publisher".
    if (role !== 'publisher') {
      setSaveMessage('You must be logged in as a publisher to save a listing.');
      return;
    }

    // Prepare payload: include publisher_id, listing details, and selected frames
    const payload = {
      publisher_id: session.user.id,
      title: listingDetails.title,
      category: listingDetails.category,
      website: listingDetails.website,
      selected_frames: selectedFrames,
    };

    const { data, error } = await supabase
      .from('listings')
      .insert([payload]);

    if (error) {
      console.error('Error saving listing:', error);
      setSaveMessage('Error saving listing: ' + error.message);
    } else {
      setSaveMessage('Listing saved successfully!');
      console.log('Listing saved:', data);
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-4 text-white">
      {/* Page Title */}
      <h1 className="text-3xl font-bold mb-6">Create Listing</h1>

      {/* Listing Details Section */}
      <div className="mb-6">
        <h2 className="text-xl mb-2 font-semibold">Listing Details</h2>

        {/* Title Input */}
        <label className="block mb-2">
          <span className="block mb-1">Title:</span>
          <input
            type="text"
            name="title"
            value={listingDetails.title}
            onChange={handleDetailChange}
            className="border p-2 w-full bg-gray-800 text-white placeholder-gray-400"
            placeholder="Enter a listing title"
          />
        </label>

        {/* Category Select */}
        <label className="block mb-2">
          <span className="block mb-1">Category:</span>
          <select
            name="category"
            value={listingDetails.category}
            onChange={handleDetailChange}
            className="border p-2 w-full bg-gray-800 text-white placeholder-gray-400"
          >
            <option value="">Select a category</option>
            <option value="Technology">Technology</option>
            <option value="Sports">Sports</option>
            <option value="Lifestyle">Lifestyle</option>
            <option value="Finance">Finance</option>
            <option value="Entertainment">Entertainment</option>
          </select>
        </label>

        {/* Website Input */}
        <label className="block mb-2">
          <span className="block mb-1">Publisher Website URL:</span>
          <input
            type="text"
            name="website"
            value={listingDetails.website}
            onChange={handleDetailChange}
            className="border p-2 w-full bg-gray-800 text-white placeholder-gray-400"
            placeholder="https://example.com"
          />
        </label>
      </div>

      {/* Available Ad Frames Section */}
      <div className="mb-6">
        <h2 className="text-xl mb-2 font-semibold">Available Ad Frames</h2>
        {availableFrames.map((frame) => {
          const isSelected = !!selectedFrames[frame.id];
          return (
            <div key={frame.id} className="flex items-center mb-2">
              <input
                type="checkbox"
                id={frame.id}
                checked={isSelected}
                onChange={() => toggleFrame(frame.id)}
                className="mr-2 form-checkbox h-5 w-5 text-blue-500"
              />
              <label htmlFor={frame.id} className="mr-4">
                {frame.size}
              </label>
              {isSelected && (
                <input
                  type="number"
                  placeholder="Price per click"
                  value={selectedFrames[frame.id].pricePerClick}
                  onChange={(e) => updatePrice(frame.id, e.target.value)}
                  className="border px-2 py-1 w-40 bg-gray-800 text-white placeholder-gray-400"
                />
              )}
            </div>
          );
        })}
      </div>

      {/* Generate HTML Code Button */}
      <button
        onClick={generateCode}
        className="px-4 py-2 bg-blue-600 text-white rounded mb-4"
      >
        Generate HTML Code
      </button>

      {/* Embed Code Display */}
      {embedCode && (
        <div className="mb-4">
          <h2 className="text-xl mb-2 font-semibold">Your Embed Code:</h2>
          <textarea
            readOnly
            value={embedCode}
            className="w-full h-40 p-2 border rounded bg-gray-800 text-white placeholder-gray-400"
          />
        </div>
      )}

      {/* Copy Code & Save Listing Buttons */}
      <div className="mb-4 flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-2 sm:space-y-0">
        {embedCode && (
          <button
            onClick={() => navigator.clipboard.writeText(embedCode)}
            className="px-4 py-2 bg-green-600 text-white rounded"
          >
            Copy Code
          </button>
        )}
        <button
          onClick={saveListing}
          className="px-4 py-2 bg-purple-600 text-white rounded"
        >
          Save Listing
        </button>
      </div>

      {/* Display Save Message */}
      {saveMessage && (
        <p className="mt-2 text-sm text-gray-200">{saveMessage}</p>
      )}

      {/* Debug Output (Optional) */}
      <div className="mt-4">
        <p className="text-gray-300">Selected Frames JSON:</p>
        <pre className="bg-gray-800 p-2 rounded text-white">
          {JSON.stringify(selectedFrames, null, 2)}
        </pre>
      </div>
    </div>
  );
};

export default CreateListing;












