import React, { useState } from 'react';
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client with your anon key
const supabase = createClient(
  'https://pczzwgluhgrjuxjadyaq.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBjenp3Z2x1aGdyanV4amFkeWFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDAxNjY0MTQsImV4cCI6MjA1NTc0MjQxNH0.dpVupxUEf8be6aMG8jJZFduezZjaveCnUhI9p7G7ud0'
);

// Predefined list of publisher categories
const categories = ['Technology', 'Sports', 'Lifestyle', 'Finance', 'Entertainment'];

export default function CreateCampaign({ session }) {
  // ===============================
  // STATE DECLARATIONS
  // ===============================
  const [step, setStep] = useState(1);
  const [error, setError] = useState(null);
  const [submitted, setSubmitted] = useState(false);

  // Step 1: Publisher search state
  const [selectedCategory, setSelectedCategory] = useState('');
  const [publisherResults, setPublisherResults] = useState([]);
  const [selectedPublishers, setSelectedPublishers] = useState([]);

  // Step 2: Campaign details state
  const [campaignDetails, setCampaignDetails] = useState({
    title: '',
    budget: '',
    dailyLimit: '',
    targetURL: '',
    endDate: { year: '', month: '', day: '' },
  });

  // Step 3: Publisher-specific details (frame selections, file uploads)
  // Structure: { publisherId: { framesChosen: { frameKey: true, ... }, uploads: { frameKey: "filePath", ... } } }
  const [publisherDetails, setPublisherDetails] = useState({});

  // ===============================
  // STEP 1: SEARCH PUBLISHERS
  // ===============================
  const handleSearchPublishers = async () => {
    setError(null);
    if (!selectedCategory) {
      setError('Please select a category.');
      return;
    }
    try {
      const { data, error } = await supabase
        .from('listings')
        .select('id, website, category, selected_frames, publisher_name')
        .eq('category', selectedCategory);
      if (error) throw error;
      setPublisherResults(data || []);
    } catch (err) {
      setError(err.message);
    }
  };

  const togglePublisherSelection = (pub) => {
    if (selectedPublishers.some((p) => p.id === pub.id)) {
      setSelectedPublishers(selectedPublishers.filter((p) => p.id !== pub.id));
      const updated = { ...publisherDetails };
      delete updated[pub.id];
      setPublisherDetails(updated);
    } else {
      setSelectedPublishers([...selectedPublishers, pub]);
    }
  };

  // ===============================
  // STEP 2: CAMPAIGN DETAILS
  // ===============================
  const handleCampaignDetailChange = (e) => {
    const { name, value } = e.target;
    setCampaignDetails((prev) => ({ ...prev, [name]: value }));
  };

  const handleEndDateChange = (field, val) => {
    setCampaignDetails((prev) => ({
      ...prev,
      endDate: { ...prev.endDate, [field]: val },
    }));
  };

  // ===============================
  // STEP 3: PUBLISHER-SPECIFIC DETAILS
  // ===============================
  const handlePublisherDetailChange = (pubId, field, val) => {
    setPublisherDetails((prev) => ({
      ...prev,
      [pubId]: { ...prev[pubId], [field]: val },
    }));
  };

  const toggleFrameChoice = (pubId, frameKey, isSelected) => {
    setPublisherDetails((prev) => {
      const existing = prev[pubId] || {};
      const framesChosen = existing.framesChosen || {};
      return {
        ...prev,
        [pubId]: {
          ...existing,
          framesChosen: { ...framesChosen, [frameKey]: isSelected },
        },
      };
    });
  };

  const handleFileUpload = async (e, pubId, frameKey) => {
    const file = e.target.files && e.target.files[0];
    if (!file) {
      alert('No file selected.');
      return;
    }
    const bucketName = 'ad-creatives';
    const filePath = `${pubId}/${frameKey}/${Date.now()}_${file.name}`;
    try {
      const { error } = await supabase.storage.from(bucketName).upload(filePath, file);
      if (error) throw new Error('File upload failed: ' + error.message);
      setPublisherDetails((prev) => ({
        ...prev,
        [pubId]: {
          ...prev[pubId],
          uploads: { ...prev[pubId]?.uploads, [frameKey]: filePath },
        },
      }));
      alert(`File uploaded successfully: ${filePath}`);
    } catch (err) {
      setError(err.message);
    }
  };

  // ===============================
  // STEP 5: FINAL SUBMISSION
  // ===============================
  const finalSubmit = async () => {
    setError(null);
    if (!session || !session.user) {
      setError('User not authenticated.');
      return;
    }
    const payload = {
      advertiser_id: session.user.id, // Add advertiser_id to payload
      name: campaignDetails.title, // Satisfies NOT NULL constraint on campaigns.name
      campaign_details: campaignDetails,
      selected_publishers: selectedPublishers.map((pub) => {
        const pubId = pub.id;
        const framesChosen = publisherDetails[pubId]?.framesChosen || {};
        const purchasedFrames = Object.entries(framesChosen)
          .filter(([_, isSelected]) => isSelected)
          .map(([frameKey]) => {
            const frameData = pub.selected_frames?.[frameKey];
            return {
              size: frameData?.size || 'Unknown Dimensions',
              pricePerClick: frameData?.pricePerClick || 'N/A',
              uploadedFile: publisherDetails[pubId]?.uploads?.[frameKey] || null,
            };
          });
        return {
          id: pub.id,
          url: pub.website || 'No URL',
          frames_purchased: purchasedFrames,
          extra_details: publisherDetails[pubId] || {},
        };
      }),
    };

    try {
      const { data, error } = await supabase.from('campaigns').insert([payload]);
      if (error) throw error;
      setSubmitted(true);
    } catch (err) {
      setError(err.message);
    }
  };

  // ===============================
  // HELPER FUNCTION: Convert file path to public URL
  // ===============================
  const getPublicUrl = (filePath) => {
    return `https://pczzwgluhgrjuxjadyaq.supabase.co/storage/v1/object/public/ad-creatives/${filePath}`;
  };

  // ===============================
  // RENDER STEPS
  // ===============================
  const renderStep = () => {
    switch (step) {
      // --- STEP 1: Select Publisher Category & Search Results ---
      case 1:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Step 1: Select Publisher Category</h2>
            <label className="block font-medium">
              Category:
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="border p-2 mt-1 text-white bg-gray-800 appearance-none"
              >
                <option value="">Select a category</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </label>
            <button onClick={handleSearchPublishers} className="bg-blue-500 text-white px-4 py-2 rounded">
              Search Publishers
            </button>
            <div>
              <h3 className="text-2xl font-semibold mt-4">Search Results:</h3>
              {publisherResults.length > 0 ? (
                <div className="space-y-2">
                  {publisherResults.map((pub) => (
                    <div key={pub.id} className="border p-2 rounded">
                      <label className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={selectedPublishers.some((p) => p.id === pub.id)}
                          onChange={() => togglePublisherSelection(pub)}
                          className="form-checkbox text-blue-500"
                        />
                        <span>
                          <strong>Website:</strong>{' '}
                          {pub.website ? (
                            <a
                              href={pub.website}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-400 underline"
                            >
                              {pub.website}
                            </a>
                          ) : (
                            'Unknown Publisher'
                          )}{' '}
                          (ID: {pub.id})
                        </span>
                      </label>
                      {pub.selected_frames && Object.keys(pub.selected_frames).length > 0 && (
                        <div className="ml-6 mt-1">
                          <strong>Ad Frame Dimension(s) and Prices:</strong>
                          <ul className="list-disc list-inside">
                            {Object.entries(pub.selected_frames).map(([frameKey, frameData]) => (
                              <li key={frameKey}>
                                {frameData.size || 'Unknown Dimensions'} - ${frameData.pricePerClick}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p>No publishers found for this category.</p>
              )}
            </div>
            <div className="flex justify-end">
              <button onClick={() => setStep(2)} className="bg-green-500 text-white px-4 py-2 rounded">
                Next
              </button>
            </div>
          </div>
        );

      // --- STEP 2: Enter Campaign Details ---
      case 2:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Step 2: Enter Campaign Details</h2>
            <div>
              <label className="block font-medium">
                Campaign Title:
                <input
                  type="text"
                  name="title"
                  value={campaignDetails.title}
                  onChange={handleCampaignDetailChange}
                  className="border p-2 mt-1 text-white bg-gray-800 w-full appearance-none"
                />
              </label>
            </div>
            <div>
              <label className="block font-medium">
                Campaign Budget ($):
                <input
                  type="number"
                  name="budget"
                  value={campaignDetails.budget}
                  onChange={handleCampaignDetailChange}
                  className="border p-2 mt-1 text-white bg-gray-800 w-full appearance-none"
                />
              </label>
            </div>
            <div>
              <label className="block font-medium">
                Daily Spend Limit ($):
                <input
                  type="number"
                  name="dailyLimit"
                  value={campaignDetails.dailyLimit}
                  onChange={handleCampaignDetailChange}
                  className="border p-2 mt-1 text-white bg-gray-800 w-full appearance-none"
                />
              </label>
            </div>
            <div>
              <label className="block font-medium">
                Target URL:
                <input
                  type="text"
                  name="targetURL"
                  value={campaignDetails.targetURL}
                  onChange={handleCampaignDetailChange}
                  className="border p-2 mt-1 text-white bg-gray-800 w-full appearance-none"
                />
              </label>
            </div>
            <div>
              <label className="block font-medium mb-1">End Date:</label>
              <div className="flex items-center space-x-4">
                <div>
                  <span className="mr-1">Year:</span>
                  <input
                    type="number"
                    value={campaignDetails.endDate.year}
                    onChange={(e) => handleEndDateChange('year', e.target.value)}
                    className="border p-2 text-white bg-gray-800 w-20 appearance-none"
                  />
                </div>
                <div>
                  <span className="mr-1">Month:</span>
                  <input
                    type="number"
                    value={campaignDetails.endDate.month}
                    onChange={(e) => handleEndDateChange('month', e.target.value)}
                    className="border p-2 text-white bg-gray-800 w-20 appearance-none"
                  />
                </div>
                <div>
                  <span className="mr-1">Day:</span>
                  <input
                    type="number"
                    value={campaignDetails.endDate.day}
                    onChange={(e) => handleEndDateChange('day', e.target.value)}
                    className="border p-2 text-white bg-gray-800 w-20 appearance-none"
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-between mt-4">
              <button onClick={() => setStep(1)} className="bg-gray-500 text-white px-4 py-2 rounded">
                Back
              </button>
              <button onClick={() => setStep(3)} className="bg-green-500 text-white px-4 py-2 rounded">
                Next
              </button>
            </div>
          </div>
        );

      // --- STEP 3: Publisher-Specific Details, Frame Selection & File Upload ---
      case 3:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Step 3: Add Publisher-Specific Details</h2>
            {selectedPublishers.length > 0 ? (
              selectedPublishers.map((pub) => {
                const pubId = pub.id;
                const frames = pub.selected_frames || {};
                return (
                  <div key={pubId} className="border p-4 rounded mb-4">
                    <h3 className="font-semibold">
                      Publisher: {pub.publisher_name ? pub.publisher_name : (pub.website || 'Unknown Publisher')} (ID: {pub.id})
                    </h3>
                    <p>
                      Website:{' '}
                      {pub.website ? (
                        <a
                          href={pub.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-400 underline"
                        >
                          {pub.website}
                        </a>
                      ) : (
                        'No URL'
                      )}
                    </p>
                    {Object.keys(frames).length > 0 ? (
                      <div className="ml-4 mt-2">
                        <strong>Select Frames to Purchase:</strong>
                        <ul className="list-disc list-inside">
                          {Object.entries(frames).map(([frameKey, frameData]) => {
                            const isChosen = !!publisherDetails[pubId]?.framesChosen?.[frameKey];
                            const size = frameData.size || 'Unknown Dimensions';
                            return (
                              <li key={frameKey} className="mt-1">
                                <label className="flex items-center space-x-2">
                                  <input
                                    type="checkbox"
                                    checked={isChosen}
                                    onChange={(e) => toggleFrameChoice(pubId, frameKey, e.target.checked)}
                                    className="form-checkbox text-blue-500"
                                  />
                                  <span>{size} - Price: ${frameData.pricePerClick}</span>
                                </label>
                                {isChosen && (
                                  <div className="ml-8 mt-2">
                                    <input
                                      type="file"
                                      onChange={(e) => handleFileUpload(e, pubId, frameKey)}
                                      className="border p-2 text-white bg-gray-800 appearance-none"
                                    />
                                  </div>
                                )}
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    ) : (
                      <p className="mt-2">No frames set by this publisher.</p>
                    )}
                  </div>
                );
              })
            ) : (
              <p>No publishers selected.</p>
            )}
            <div className="flex justify-between">
              <button onClick={() => setStep(2)} className="bg-gray-500 text-white px-4 py-2 rounded">
                Back
              </button>
              <button onClick={() => setStep(4)} className="bg-green-500 text-white px-4 py-2 rounded">
                Next
              </button>
            </div>
          </div>
        );

      // --- STEP 4: Review Campaign Details with Card UI ---
      case 4:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Step 4: Review Campaign Details</h2>
            <div className="border p-4 rounded shadow">
              <h3 className="font-bold">Campaign Details</h3>
              <p><strong>Title:</strong> {campaignDetails.title}</p>
              <p><strong>Budget:</strong> ${campaignDetails.budget}</p>
              <p><strong>Daily Spend Limit:</strong> ${campaignDetails.dailyLimit}</p>
              <p>
                <strong>Target URL:</strong>{' '}
                {campaignDetails.targetURL ? (
                  <a
                    href={campaignDetails.targetURL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 underline"
                  >
                    {campaignDetails.targetURL}
                  </a>
                ) : (
                  'N/A'
                )}
              </p>
              <p>
                <strong>End Date:</strong> {campaignDetails.endDate.year}-
                {campaignDetails.endDate.month}-{campaignDetails.endDate.day}
              </p>
            </div>
            <div className="border p-4 rounded shadow">
              <h3 className="font-bold">Selected Publishers</h3>
              {selectedPublishers.map((pub) => (
                <div key={pub.id} className="border p-2 rounded mb-2">
                  <p>
                    <strong>Website:</strong>{' '}
                    {pub.website ? (
                      <a
                        href={pub.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-400 underline"
                      >
                        {pub.website}
                      </a>
                    ) : (
                      'No URL'
                    )}
                  </p>
                  {pub.selected_frames && Object.keys(pub.selected_frames).length > 0 && (
                    <div className="mt-2">
                      <strong>Ad Frame Dimension(s) and Prices:</strong>
                      <ul className="list-disc list-inside ml-4">
                        {Object.entries(pub.selected_frames).map(([frameKey, frameData]) => {
                          const size = frameData.size || 'Unknown Dimensions';
                          const uploadedFile = publisherDetails[pub.id]?.uploads?.[frameKey];
                          return (
                            <li key={frameKey}>
                              {size} - Price: ${frameData.pricePerClick}
                              {uploadedFile && (
                                <div className="mt-1">
                                  <img
                                    src={getPublicUrl(uploadedFile)}
                                    alt={`${size} ad`}
                                    className="max-w-xs border"
                                  />
                                </div>
                              )}
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div className="flex justify-between">
              <button onClick={() => setStep(3)} className="bg-gray-500 text-white px-4 py-2 rounded">
                Back
              </button>
              <button onClick={() => setStep(5)} className="bg-green-500 text-white px-4 py-2 rounded">
                Submit Campaign
              </button>
            </div>
          </div>
        );

      // --- STEP 5: Final Submission ---
      case 5:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold">Step 5: Finalizing Campaign...</h2>
            {!submitted ? (
              <button
                className="bg-blue-500 text-white px-4 py-2 rounded"
                onClick={finalSubmit}
              >
                Confirm Submit
              </button>
            ) : (
              <p className="text-green-600">Campaign Submitted Successfully!</p>
            )}
          </div>
        );

      default:
        return <div>Invalid Step</div>;
    }
  };

  // ===============================
  // RENDER COMPONENT
  // ===============================
  return (
    <div className="p-4 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Create Campaign</h1>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      {renderStep()}
    </div>
  );
}

