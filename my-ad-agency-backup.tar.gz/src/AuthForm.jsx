import React, { useState } from 'react';
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client with your anon key
const supabase = createClient(
  'https://pczzwgluhgrjuxjadyaq.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBjenp3Z2x1aGdyanV4amFkeWFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDAxNjY0MTQsImV4cCI6MjA1NTc0MjQxNH0.dpVupxUEf8be6aMG8jJZFduezZjaveCnUhI9p7G7ud0'
);

function AuthForm({ setSession }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('publisher'); // Default role is publisher
  const [error, setError] = useState(null);

  // Handle signup with role selection
  const handleSignup = async (e) => {
    e.preventDefault();
    setError(null);

    // Sign up using Supabase Auth
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) {
      setError(error.message);
      return;
    }

    const user = data.user;
    if (!user) {
      setError('No user data returned from signup.');
      return;
    }

    // Insert the chosen role into the profiles table
    const { error: profileError } = await supabase
      .from('profiles')
      .insert([{ id: user.id, role }]);
    if (profileError) {
      setError(profileError.message);
      return;
    }

    setSession(data.session);
  };

  // Handle login
  const handleLogin = async (e) => {
    e.preventDefault();
    setError(null);
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setError(error.message);
    else setSession(data.session);
  };

  return (
    <div className="p-4 bg-blue-500 text-white min-h-screen">
      <h1 className="text-2xl mb-4">Welcome to AdSync</h1>
      <form onSubmit={handleSignup} className="mb-4">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          className="p-2 mb-2 w-full rounded"
          autoComplete="email"
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          className="p-2 mb-2 w-full rounded"
          autoComplete="current-password"
        />
        {/* Role selection dropdown */}
        <div className="mb-2">
          <label className="mr-2">Role:</label>
          <select
            value={role}
            onChange={(e) => setRole(e.target.value)}
            className="text-black p-1 rounded"
          >
            <option value="publisher">Publisher</option>
            <option value="advertiser">Advertiser</option>
          </select>
        </div>
        <button type="submit" className="bg-green-500 p-2 rounded">Sign Up</button>
      </form>
      <form onSubmit={handleLogin} className="mb-4">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          className="p-2 mb-2 w-full rounded"
          autoComplete="email"
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          className="p-2 mb-2 w-full rounded"
          autoComplete="current-password"
        />
        <button type="submit" className="bg-blue-600 p-2 rounded">Login</button>
      </form>
      {error && <p className="text-red-500">{error}</p>}
    </div>
  );
}

export default AuthForm;
