import React from 'react';

function DashboardLayout({ children, user, onLogout }) {
  return (
    <div className="min-h-screen bg-gray-900 text-white flex">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 p-4 fixed top-0 left-0 bottom-0">
        <div className="mb-8">
          <h1 className="text-2xl font-bold">LOGO</h1>
        </div>
        <nav>
          <ul>
            <li className="mb-4">
              <a href="/publisher-dashboard" className="hover:text-gray-300">Publisher Dashboard</a>
            </li>
            <li className="mb-4">
              <a href="/create-listing" className="hover:text-gray-300">Create Listing</a>
            </li>
            <li className="mb-4">
              <a href="/advertiser-dashboard" className="hover:text-gray-300">Advertiser Dashboard</a>
            </li>
            <li>
              <a href="/create-campaign" className="hover:text-gray-300">Create Campaign</a>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 ml-64">
        {/* Top Navigation */}
        <header className="bg-gray-800 p-4 fixed top-0 left-64 right-0">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Dashboard</h2>
            <div>
              <span className="mr-4">Hello, {user?.email}</span>
              <button 
                onClick={onLogout}
                className="bg-red-500 px-3 py-1 rounded hover:bg-red-600"
              >
                Logout
              </button>
            </div>
          </div>
        </header>
        
        {/* Content */}
        <main className="mt-16 p-4">
          {children}
        </main>
      </div>
    </div>
  );
}

export default DashboardLayout;
