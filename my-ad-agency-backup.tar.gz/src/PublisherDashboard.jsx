import React, { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';

// Supabase client (using the same anon key as your other frontend files)
const supabase = createClient(
  'https://pczzwgluhgrjuxjadyaq.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBjenp3Z2x1aGdyanV4amFkeWFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDAxNjY0MTQsImV4cCI6MjA1NTc0MjQxNH0.dpVupxUEf8be6aMG8jJZFduezZjaveCnUhI9p7G7ud0'
);

const PublisherDashboard = () => {
  const [listings, setListings] = useState([]);
  const [error, setError] = useState(null);
  
  // For editing a listing
  const [editingListing, setEditingListing] = useState(null);
  const [tempFrames, setTempFrames] = useState('');

  // Fetch all listings on component mount
  useEffect(() => {
    fetchListings();
  }, []);

  const fetchListings = async () => {
    setError(null);
    try {
      const { data, error } = await supabase
        .from('listings')
        .select('*');
      if (error) {
        console.error('Error fetching listings:', error);
        setError(error.message);
      } else {
        setListings(data);
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      setError(err.message);
    }
  };

  // When user clicks the Edit button, open edit mode
  const handleEditClick = (listing) => {
    setEditingListing(listing);
    // Convert selected_frames JSON to a string for editing
    setTempFrames(JSON.stringify(listing.selected_frames, null, 2));
  };

  // Cancel editing mode
  const handleCancelEdit = () => {
    setEditingListing(null);
    setTempFrames('');
  };

  // Save the edited listing by sending updated selected_frames to the backend
  const handleSaveEdit = async () => {
    setError(null);
    try {
      // Parse the JSON from the text area
      const parsed = JSON.parse(tempFrames);
      const response = await fetch(`http://localhost:3000/listings/${editingListing.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ selected_frames: parsed }),
      });
      if (!response.ok) {
        const msg = await response.text();
        throw new Error(msg || 'Failed to update listing');
      }
      // Refetch listings after update
      await fetchListings();
      setEditingListing(null);
      setTempFrames('');
    } catch (err) {
      console.error('Error saving edit:', err);
      setError(err.message);
    }
  };

  // Delete listing function
  const handleDelete = async (listingId) => {
    setError(null);
    try {
      const { error } = await supabase
        .from('listings')
        .delete()
        .eq('id', listingId);
      if (error) {
        throw error;
      }
      // Refetch listings after deletion
      await fetchListings();
    } catch (err) {
      console.error('Error deleting listing:', err);
      setError(err.message);
    }
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Publisher Dashboard</h1>
      {error && <p className="text-red-500 mb-2">Error: {error}</p>}
      
      {editingListing ? (
        <div className="mb-4 border p-2">
          <h2 className="font-bold mb-2">Editing Listing: {editingListing.id}</h2>
          <label className="block mb-1">selected_frames (JSON):</label>
          <textarea
            className="border w-full h-40 p-2"
            value={tempFrames}
            onChange={(e) => setTempFrames(e.target.value)}
          />
          <div className="mt-2">
            <button
              onClick={handleSaveEdit}
              className="bg-blue-500 text-white px-3 py-1 mr-2 rounded"
            >
              Save
            </button>
            <button
              onClick={handleCancelEdit}
              className="bg-gray-300 text-black px-3 py-1 rounded"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : null}

      {listings.length > 0 ? (
        <table className="min-w-full bg-white">
          <thead>
            <tr>
              <th className="border px-4 py-2">Listing ID</th>
              <th className="border px-4 py-2">Selected Frames</th>
              <th className="border px-4 py-2">Created At</th>
              <th className="border px-4 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {listings.map((listing) => (
              <tr key={listing.id}>
                <td className="border px-4 py-2">{listing.id}</td>
                <td className="border px-4 py-2">
                  {JSON.stringify(listing.selected_frames)}
                </td>
                <td className="border px-4 py-2">{listing.created_at}</td>
                <td className="border px-4 py-2">
                  <button
                    onClick={() => handleEditClick(listing)}
                    className="bg-yellow-500 text-white px-3 py-1 rounded mr-2"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(listing.id)}
                    className="bg-red-500 text-white px-3 py-1 rounded"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No listings found.</p>
      )}
    </div>
  );
}

export default PublisherDashboard;

